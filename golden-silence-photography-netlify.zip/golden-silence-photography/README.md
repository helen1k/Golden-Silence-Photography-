# Golden Silence Photography

A responsive photography portfolio website designed for Netlify.

## Deploy for free
1. Create a free Netlify account.
2. Open Netlify Drop: https://app.netlify.com/drop
3. Drag the `golden-silence-photography` folder into the drop zone.
4. Netlify will publish a `netlify.app` URL.
5. Use **Customize** beside the preview URL to set a name such as `goldensilencephotography`.

The demo gallery uses Unsplash-hosted images. Replace the image URLs in `index.html` with your own photography before publishing commercially.
